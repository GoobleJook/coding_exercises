Course - Introduction to the Google Maps API

Lesson 6.2 - Marker Options