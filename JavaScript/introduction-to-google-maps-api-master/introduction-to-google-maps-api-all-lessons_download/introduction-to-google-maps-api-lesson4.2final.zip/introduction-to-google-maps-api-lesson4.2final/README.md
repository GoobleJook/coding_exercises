Course - Introduction to the Google Maps API

Lesson 4.2 - Map Styles