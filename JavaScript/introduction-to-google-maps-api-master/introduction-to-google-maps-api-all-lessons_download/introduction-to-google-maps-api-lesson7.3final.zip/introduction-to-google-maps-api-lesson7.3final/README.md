Course - Introduction to the Google Maps API

Map shows on-time arrivals and departures as a percentage and total from US airports for the month of December 2014.

The size of the airplane icons indicates the total traffic for the month, while the color indicates the on-time arrival/departure average percentage.

