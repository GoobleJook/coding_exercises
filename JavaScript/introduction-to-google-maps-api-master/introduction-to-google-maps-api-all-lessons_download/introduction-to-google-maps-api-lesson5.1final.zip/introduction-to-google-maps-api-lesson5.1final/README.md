Course - Introduction to the Google Maps API

Lesson 5.1 - Map Methods and Events