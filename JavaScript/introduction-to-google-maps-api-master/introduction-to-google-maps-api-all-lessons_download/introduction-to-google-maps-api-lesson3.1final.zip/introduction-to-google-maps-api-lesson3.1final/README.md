Course - Introduction to the Google Maps API

Lesson 3.1 - Creating Your First Map