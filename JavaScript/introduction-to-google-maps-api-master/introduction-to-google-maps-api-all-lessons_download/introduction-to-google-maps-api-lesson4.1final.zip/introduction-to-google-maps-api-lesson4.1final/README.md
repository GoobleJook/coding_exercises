Course - Introduction to the Google Maps API

Lesson 4.1 - Basic Map Options