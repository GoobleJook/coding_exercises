Course - Introduction to the Google Maps API

Lesson 6.1 - Marker Creation